import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

NEG_PATH = "MAPRED_NEGATIVEWORDS_CLEANED.csv"   # expects columns: word,count
POS_PATH = "MAPRED_POSITIVEWORDS_CLEANED.csv"

TOP_K     = 20     # for top-word bars and overlap plots
LEADER_K  = 15     # for leaderboards
MIN_TOTAL = 5000   
ALPHA     = 0.5    

df_neg = pd.read_csv(NEG_PATH)  # columns: word, count
df_pos = pd.read_csv(POS_PATH)

# 1 Basic Frequency Chart
def bar_topk(df, title, outfile):
    top = df.sort_values("count", ascending=False).head(TOP_K)
    plt.figure(figsize=(10, 6))
    plt.barh(top["word"][::-1], top["count"][::-1])
    plt.title(title)
    plt.xlabel("Count")
    plt.ylabel("Word")
    plt.tight_layout()
    plt.savefig(outfile, dpi=150)
    plt.show()

bar_topk(df_pos, f"Top {TOP_K} Positive Words (by count)", f"top{TOP_K}_positive_bar.png")
bar_topk(df_neg, f"Top {TOP_K} Negative Words (by count)", f"top{TOP_K}_negative_bar.png")

#2 Overlap Analysis
overlap = pd.merge(
    df_pos.rename(columns={"count": "pos_count"}),
    df_neg.rename(columns={"count": "neg_count"}),
    on="word", how="inner"
)
overlap["total"] = overlap["pos_count"] + overlap["neg_count"]
overlap["bias"]  = (overlap["pos_count"] - overlap["neg_count"]) / overlap["total"]

ov_total = overlap.sort_values(["total", "word"], ascending=[False, True]).head(TOP_K)
plt.figure(figsize=(10, 6))
plt.barh(ov_total["word"][::-1], ov_total["total"][::-1])
plt.title(f"Overlap Words (Top {TOP_K} by total occurrences)")
plt.xlabel("Total occurrences (pos + neg)")
plt.ylabel("Word")
plt.tight_layout()
plt.savefig("overlap_top_total_bar.png", dpi=150)
plt.show()

ov_abs = overlap.reindex(overlap.index[np.argsort(-overlap["bias"].abs().values)]).head(TOP_K)
plt.figure(figsize=(10, 6))
plt.barh(ov_abs["word"][::-1], ov_abs["bias"][::-1])
plt.title(f"Overlap Words (Top {TOP_K} by |bias|)")
plt.xlabel("Bias = (pos - neg) / (pos + neg)")
plt.ylabel("Word")
plt.tight_layout()
plt.savefig("overlap_top_absbias_bar.png", dpi=150)
plt.show()

#3 Polarity Leaderboards and Comparison
def barh_bias(df, title, outfile):
    plt.figure(figsize=(10, 6))
    plt.barh(df["word"][::-1], df["bias"][::-1])
    plt.title(title + " (overlap only)")
    plt.xlabel("Bias = (pos - neg) / (pos + neg)")
    plt.ylabel("Word")
    plt.tight_layout()
    plt.savefig(outfile, dpi=150)
    plt.show()

pos_overlap = overlap.sort_values(["bias", "total"], ascending=[False, False]).head(LEADER_K)
neg_overlap = overlap.sort_values(["bias", "total"], ascending=[True,  False]).head(LEADER_K)

barh_bias(pos_overlap, f"Top {LEADER_K} Positive-skewed Words", "overlap_leader_positive_bar.png")
barh_bias(neg_overlap, f"Top {LEADER_K} Negative-skewed Words", "overlap_leader_negative_bar.png")

combo = pd.merge(
    df_pos.rename(columns={"count": "pos_count"}),
    df_neg.rename(columns={"count": "neg_count"}),
    on="word", how="outer"
).fillna(0)

pos_total = combo["pos_count"].sum()
neg_total = combo["neg_count"].sum()
V = combo.shape[0]

combo["pos_share"] = (combo["pos_count"] + ALPHA) / (pos_total + ALPHA * V)
combo["neg_share"] = (combo["neg_count"] + ALPHA) / (neg_total + ALPHA * V)

combo["log_lift"] = np.log(combo["pos_share"] / combo["neg_share"]) / np.log(2)
combo["total"]    = combo["pos_count"] + combo["neg_count"]

lift_filtered = combo[combo["total"] >= MIN_TOTAL].copy()

pos_lift = lift_filtered.sort_values(["log_lift", "total"], ascending=[False, False]).head(LEADER_K)
neg_lift = lift_filtered.sort_values(["log_lift", "total"], ascending=[True,  False]).head(LEADER_K)

def barh_lift(df, title, outfile):
    plt.figure(figsize=(10, 6))
    plt.barh(df["word"][::-1], df["log_lift"][::-1])
    plt.title(title + f" (log2 lift, α={ALPHA})")
    plt.xlabel("log2(pos_share / neg_share)")
    plt.ylabel("Word")
    plt.tight_layout()
    plt.savefig(outfile, dpi=150)
    plt.show()

barh_lift(pos_lift, f"Most Positive-tilted Words (top {LEADER_K})", "loglift_leader_positive_bar.png")
barh_lift(neg_lift, f"Most Negative-tilted Words (top {LEADER_K})", "loglift_leader_negative_bar.png")

print("Finished")
