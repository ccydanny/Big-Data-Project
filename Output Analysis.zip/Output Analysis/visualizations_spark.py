import pandas as pd
import matplotlib.pyplot as plt


POS_FILES = "Spark_Positive.csv"  #rename files!!
NEG_FILES = "Spark_Negative.csv"
TOP_K = 30

def _to_file_list(spec):
    if isinstance(spec, list):
        return spec
    if isinstance(spec, str):
        return [s.strip() for s in spec.split(",") if s.strip()]
    raise ValueError("POS_FILES/NEG_FILES must be a string or list of strings.")

def _read_one_csv(path):
    df = pd.read_csv(path)
    cols = [c.strip().lower() for c in df.columns]
    if ("word" not in cols) or ("count" not in cols):
        df = pd.read_csv(path, header=None, usecols=[0,1], names=["word","count"])
    else:
        df.columns = cols
        df = df[["word","count"]]
    df["count"] = pd.to_numeric(df["count"], errors="coerce").fillna(0)
    return df

def load_spark_outputs(files_spec):
    files = _to_file_list(files_spec)
    dfs = [_read_one_csv(f) for f in files]
    out = pd.concat(dfs, ignore_index=True)
    out = out.groupby("word", as_index=False)["count"].sum()
    out = out.sort_values("count", ascending=False)
    return out

def plot_top(df, title, outfile, k=TOP_K):
    top = df.head(k)
    plt.figure(figsize=(10, 6))
    plt.barh(top["word"][::-1], top["count"][::-1])
    plt.title(title)
    plt.xlabel("Count")
    plt.ylabel("Word")
    plt.tight_layout()
    plt.savefig(outfile, dpi=150)
    plt.show()

pos_df = load_spark_outputs(POS_FILES)
neg_df = load_spark_outputs(NEG_FILES)

plot_top(pos_df, f"Spark Top {TOP_K} Positive Words (by count)", f"spark_top{TOP_K}_positive.png")
plot_top(neg_df, f"Spark Top {TOP_K} Negative Words (by count)", f"spark_top{TOP_K}_negative.png")

print("Finished")
